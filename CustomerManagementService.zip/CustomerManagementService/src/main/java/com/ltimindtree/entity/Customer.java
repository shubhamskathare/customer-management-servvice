package com.ltimindtree.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="customers")
public class Customer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String customerName;
	private String email;
	private String password;
	private String customerCellNo;
	
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Customer(int id, String customerName, String email, String password, String customerCellNo) {
		super();
		this.id = id;
		this.customerName = customerName;
		this.email = email;
		this.password = password;
		this.customerCellNo = customerCellNo;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getCustomerCellNo() {
		return customerCellNo;
	}


	public void setCustomerCellNo(String customerCellNo) {
		this.customerCellNo = customerCellNo;
	}
	
	

}
