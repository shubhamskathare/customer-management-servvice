package com.ltimindtree.service.impl;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ltimindtree.entity.Customer;
import com.ltimindtree.exception.CustomerNotFoundException;
import com.ltimindtree.repository.CustomerRepository;
import com.ltimindtree.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public Customer saveCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerRepository.save(customer);
	}

	@Override
	public Customer updateCustomer(Customer customer, int id) throws CustomerNotFoundException  {
		// TODO Auto-generated method stub
		Customer existingCustomer=customerRepository.findById(id).orElseThrow(()->new CustomerNotFoundException("Customer", "Id", id));
		existingCustomer.setCustomerName(customer.getCustomerName());
		existingCustomer.setEmail(customer.getEmail());
		existingCustomer.setPassword(customer.getPassword());
		existingCustomer.setCustomerCellNo(customer.getCustomerCellNo());
		customerRepository.save(existingCustomer);
		return existingCustomer;
	}

	@Override
	public void deleteCustomer(int id) throws CustomerNotFoundException {
		customerRepository.findById(id).orElseThrow(()->new CustomerNotFoundException("Customer", "Id", id));
		customerRepository.deleteById(id);
	}

}
